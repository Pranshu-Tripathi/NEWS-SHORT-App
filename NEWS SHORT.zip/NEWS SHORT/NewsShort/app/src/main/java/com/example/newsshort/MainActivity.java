package com.example.newsshort;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import static android.provider.ContactsContract.CommonDataKinds.Website.URL;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> titles = new ArrayList<String>();
    ArrayList<String> contents = new ArrayList<String>();

    ArrayAdapter arrayAdapter;
    SQLiteDatabase ArticlesDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArticlesDB = this.openOrCreateDatabase("Articles",MODE_PRIVATE,null);
        ArticlesDB.execSQL("CREATE TABLE IF NOT EXISTS articles(id INTEGER PRIMARY KEY,articleId,INTEGER,title VARCHAR,content VARCHAR)");

        DownloadTask task = new DownloadTask();
        try {
            task.execute("https://hacker-news.firebaseio.com/v0/topstories.json?print=pretty\n");
        }catch (Exception e){
            e.printStackTrace();
        }

        ListView listView = (ListView) findViewById(R.id.listView);
        arrayAdapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,titles);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),ArticleActivity.class);
                intent.putExtra("url",contents.get(position));
                startActivity(intent);
            }
        });

        updateListView();
    }

    public void updateListView(){
        Cursor c = ArticlesDB.rawQuery("SELECT * FROM articles",null);
        int contentIndex = c.getColumnIndex("content");
        int titleIndex = c.getColumnIndex("title");

        if(c.moveToFirst()) {
            titles.clear();
            contents.clear();

            do {
                titles.add((titles.size()+1)+"}"+c.getString(titleIndex));
                contents.add(c.getString(contentIndex));
                c.moveToNext();
            }while (!c.isAfterLast());
            arrayAdapter.notifyDataSetChanged();
        }
    }

 // url data collection function;
    public class DownloadTask extends AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... urls) {

            String result = "";
            URL url;
            HttpURLConnection urlConnection = null;

            try {
                url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = urlConnection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                int data = inputStreamReader.read();
                while(data != -1){
                    char c = (char) data;
                    result += c;
                    data = inputStreamReader.read();
                }

                JSONArray jsonArray = new JSONArray(result);

                int numberOfItems = 20;   // this is mainly done to change the top news size

                // checking if the site sometime sends smaller length of ids, should not crash the app
                if(jsonArray.length() < numberOfItems){
                    numberOfItems = jsonArray.length();
                }

                ArticlesDB.execSQL("DELETE FROM articles");
                for (int i = 0 ; i < numberOfItems ; ++i){
                    String articleID = jsonArray.getString(i);
                    url = new URL("https://hacker-news.firebaseio.com/v0/item/"+articleID+".json?print=pretty");
                    urlConnection = (HttpURLConnection) url.openConnection();
                    inputStream = urlConnection.getInputStream();
                    inputStreamReader = new InputStreamReader(inputStream);
                    String articleInfo = "";
                    data = inputStreamReader.read();
                    while(data != -1){
                        char c = (char) data;
                        articleInfo += c;
                        data = inputStreamReader.read();
                    }
                    JSONObject jsonObject = new JSONObject(articleInfo);
                    if (!jsonObject.isNull("title") && !jsonObject.isNull("url")){
                        String articleTitle = jsonObject.getString("title");
                        String articleUrl = jsonObject.getString("url");

                        String sql = "INSERT INTO articles (articleId,title,content) VALUES (?,?,?)";
                        SQLiteStatement statement = ArticlesDB.compileStatement(sql);
                        statement.bindString(1,articleID);
                        statement.bindString(2,articleTitle);
                        statement.bindString(3,articleUrl);
                        statement.execute();
                }
                }
                return result;
            }catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }

     @Override
     protected void onPostExecute(String s) {
         super.onPostExecute(s);
         updateListView();
     }
 }
}
